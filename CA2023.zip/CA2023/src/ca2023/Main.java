/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ca2023;


 public class Main {
    public static void main(String[] args) {
        MovieRentalSystem rentalSystem = new MovieRentalSystem();

        // Create movies
        Movie movie1 = new Movie("Inception", "Sci-Fi", 2010);
        Movie movie2 = new Movie("Titanic", "Romance", 1997);

        // Add movies to the system
        rentalSystem.addMovie(movie1);
        rentalSystem.addMovie(movie2);

        // Create customers
        Customer customer1 = new Customer("John");
        Customer customer2 = new Customer("Alice");

        // Register customers
        rentalSystem.registerCustomer(customer1);
        rentalSystem.registerCustomer(customer2);

        // Display available movies
        rentalSystem.displayAvailableMovies();

        // Rent movies
        customer1.rentMovie(movie1);
        customer2.rentMovie(movie2);

        // Display available movies after rentals
        rentalSystem.displayAvailableMovies();

        // Return movies
        customer1.returnMovie(movie1);
        customer2.returnMovie(movie2);

        // Display available movies after returns
        rentalSystem.displayAvailableMovies();
    }
}
