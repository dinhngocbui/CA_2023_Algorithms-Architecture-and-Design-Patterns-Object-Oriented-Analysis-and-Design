/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ca2023;

// *
// * @author Dell
import java.util.ArrayList;
import java.util.List;

public class MovieRentalSystem {
    private List<Movie> availableMovies;
    private List<Customer> customers;

    // Constructors, getters, setters

    public void addMovie(Movie movie) {
        availableMovies.add(movie);
    }

    public void registerCustomer(Customer customer) {
        customers.add(customer);
    }

    public void displayAvailableMovies() {
        System.out.println("Available Movies:");
        availableMovies.forEach((movie) -> {
            System.out.println(movie.getTitle());
        });
    }
}
