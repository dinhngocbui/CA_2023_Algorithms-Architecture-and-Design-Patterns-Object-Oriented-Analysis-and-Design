/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ca2023;

/**
 *
 * @author Dell
 */
public class Movie {
    private String title;
    private String genre;
    private int releaseYear;
    private boolean available;

    Movie(String inception, String sciFi, int i) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    // Constructors, getters, setters

    public void rentOut() {
        if (available) {
            available = false;
            System.out.println("Movie rented: " + title);
        } else {
            System.out.println("Movie not available: " + title);
        }
    }

    public void returnMovie() {
        available = true;
        System.out.println("Movie returned: " + title);
    }

    boolean getTitle() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
