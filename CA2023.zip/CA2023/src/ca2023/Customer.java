/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ca2023;

/**
 *
 * @author Dell
 */
import java.util.ArrayList;
import java.util.List;

public class Customer {
    private String name;
    private List<Movie> rentedMovies;

    Customer(String john) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    // Constructors, getters, setters

    public void rentMovie(Movie movie) {
        rentedMovies.add(movie);
        movie.rentOut();
    }

    public void returnMovie(Movie movie) {
        rentedMovies.remove(movie);
        movie.returnMovie();
    }
}
